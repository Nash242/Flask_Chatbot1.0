import pandas as pd
from ibm_watsonx_ai.foundation_models import Model
from ibm_watsonx_ai.foundation_models.utils.enums import ModelTypes
import os
import json

# Load WatsonX credentials
with open("Credentials\watsonx_cred.json", 'r') as f:
    watsonx_cred = json.load(f)

# Load the prompt for the new task
with open("Prompt\prompt.txt", 'r') as file:
    prompt_template = file.read()

# Initialize the LLM model
print("Loading LLM Model")
model = Model(
    model_id='mistralai/mixtral-8x7b-instruct-v01',
    params=watsonx_cred['parameters'],
    credentials=watsonx_cred['credentials'],
    project_id=watsonx_cred['project_id'],
    space_id=None
)
print("Loading LLM Model Done.")

file_path = r'Sample Data\PowerBI_Booking_202404281721.csv'
data= pd.read_csv(file_path)

# Apply data type conversions
data['CreationTime']=pd.to_datetime(data['CreationTime'])
data['PickupTime']=pd.to_datetime(data['PickupTime'])
data['ActionTime']=pd.to_datetime(data['ActionTime'])
data['DispatchTime']=pd.to_datetime(data['DispatchTime'])

data[data.select_dtypes(['object']).columns] = data.select_dtypes(['object']).apply(lambda x: x.str.strip())


# object_cols = data.select_dtypes(include='object').columns
# data[object_cols] = data[object_cols].apply(lambda col: col.str.lower())
# print(df.shape)

def generate_prompt(query, prompt_template):
    # Replace the placeholder [USER_QUERY] with the actual user query
    new_prompt = prompt_template.replace('[USER_QUERY]', query)
    # print('-' * 40)
    # print(new_prompt)
    # print('-' * 40)
    return new_prompt

def perform_llm_call(query):
    global model, prompt_template
    new_prompt = generate_prompt(query, prompt_template)

    print("Calling Model")
    generated_response = model.generate_text(prompt=new_prompt, guardrails=False)
    print("Calling Model Done")
    generated_response = generated_response.replace('<end of code>', '').strip()

    compile_exec = {'data':data}
    try:
        exec(generated_response, compile_exec)
        result_msg, result_data, graph_img = compile_exec['message'], compile_exec['analyzed_df'], compile_exec['graph']
        return result_msg, result_data, graph_img, generated_response
    except Exception as e:
        msg = f"I'm sorry, I encountered an issue while trying to process your question : {str(e)} . Could you please try rephrasing it or provide more context?"
        return msg, None, None, generated_response


